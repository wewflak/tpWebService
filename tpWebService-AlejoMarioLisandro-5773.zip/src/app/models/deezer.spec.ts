import { Deezer } from './deezer';

describe('Deezer', () => {
  it('should create an instance', () => {
    expect(new Deezer()).toBeTruthy();
  });
});
