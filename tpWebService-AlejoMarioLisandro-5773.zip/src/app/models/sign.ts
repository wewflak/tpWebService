export class Sign {
    sign!: string;
    date!: string;
    language!: string;
    type!:string;
}
