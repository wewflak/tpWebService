import { Actor } from './actor';

describe('actor', () => {
  it('should create an instance', () => {
    expect(new Actor()).toBeTruthy();
  });
});
