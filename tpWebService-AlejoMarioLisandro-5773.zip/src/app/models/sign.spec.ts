import { Sign } from './sign';

describe('Sign', () => {
  it('should create an instance', () => {
    expect(new Sign()).toBeTruthy();
  });
});
