export class Actor {
    name!:string
    img!:string
    role!:string
    constructor(name:string, img:string, role:string){
        this.name = name
        this.img = img
        this.role = role
    }
}
