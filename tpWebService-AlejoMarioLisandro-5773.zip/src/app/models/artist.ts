export class Artist {
    artistID!:number
    artistName!: string
    artistPicture!: string

}
