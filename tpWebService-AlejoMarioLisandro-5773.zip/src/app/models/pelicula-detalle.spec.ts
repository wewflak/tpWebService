import { PeliculaDetalle } from './pelicula-detalle';

describe('PeliculaDetalle', () => {
  it('should create an instance', () => {
    expect(new PeliculaDetalle()).toBeTruthy();
  });
});
