import { Album } from "./album";
import { Artist } from "./artist";
import { Track } from "./track";

export class Deezer {
    objectTrack!:Track
    objectArtist!:Artist
    objectAlbum!:Album
}
