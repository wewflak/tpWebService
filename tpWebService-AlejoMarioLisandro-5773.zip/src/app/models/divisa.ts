export class Divisa {
    amount!: number;
    from!: string;
    to!: string;
}
