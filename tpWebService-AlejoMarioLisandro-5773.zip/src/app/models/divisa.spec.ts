import { Divisa } from './divisa';

describe('Divisa', () => {
  it('should create an instance', () => {
    expect(new Divisa()).toBeTruthy();
  });
});
