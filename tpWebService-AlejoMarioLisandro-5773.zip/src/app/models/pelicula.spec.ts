import { Pelicula } from './pelicula';

describe('Pelicula', () => {
  it('should create an instance', () => {
    expect(new Pelicula()).toBeTruthy();
  });
});
